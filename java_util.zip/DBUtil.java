package com.myPicture_stu.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DBUtil {
	
	/**记得导入mysql的驱动
	 * 获取数据库连接
	 * @return
	 */
	public static Connection getConnection(){
		//创建连接数据库的对象
		Connection conn = null;
		try{
			//指定连接哪一种数据库
			Class.forName("com.mysql.jdbc.Driver");
			//连接数据库的地址和参数
			String url = "jdbc:mysql://"
					+ "localhost:3306/test"
					+ "?user=root&password=root"
					+ "&characterEncoding=utf8";
			//获取连接
			conn = DriverManager.getConnection(url);
		}catch(Exception e){
			e.printStackTrace();
		}
		return conn;
	}
	/**
	 * 关闭数据库连接
	 */
	public static void closeConnection
		(Connection conn,PreparedStatement ps,ResultSet rs){
		
		try{
			if(null != rs){
				rs.close();
			}
			if(null != ps){
				ps.close();
			}
			if(null != conn){
				conn.close();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
}
